import { Router } from "express";
import { register, login, verifyOtp } from "../controllers/auth.controller";

const router = Router();

router.post("/register", register);
router.post("/verify-otp", verifyOtp);
console.log(verifyOtp);
router.post("/login", login);

export default router;
